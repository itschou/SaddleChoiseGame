(() => {
var exports = {};
exports.id = 105;
exports.ids = [105];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 1017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 7310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 3770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: [
        'tutorial',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6575)), "C:\\Users\\Stage\\Desktop\\WORKSPACE\\Jeux\\app\\tutorial\\page.tsx"],
          
        }]
      },
        {
        
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 1921)), "C:\\Users\\Stage\\Desktop\\WORKSPACE\\Jeux\\app\\layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        metadata: {
    icon: [(async (props) => (await Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 7481))).default(props))],
    apple: [],
    openGraph: [],
    twitter: [],
    manifest: undefined
  }
      }
      ]
      }.children;
const pages = ["C:\\Users\\Stage\\Desktop\\WORKSPACE\\Jeux\\app\\tutorial\\page.tsx"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/tutorial/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_PAGE,
        page: "/tutorial/page",
        pathname: "/tutorial",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 6439:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2806))

/***/ }),

/***/ 2806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./app/data/ridersData.ts
var ridersData = __webpack_require__(255);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/react-dnd/dist/hooks/useDrag/useDrag.js + 9 modules
var useDrag = __webpack_require__(3783);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/components/riderCardTuto.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 




const RiderCardTuto = ({ id, imageURL, score, lastName, firstName })=>{
    const [isActif, setActif] = (0,react_.useState)(true);
    const [ridersDataa, setRidersData] = (0,react_.useState)(ridersData/* default */.Z);
    const [{ isDragging }, drag] = (0,useDrag/* useDrag */.c)(()=>({
            type: "image",
            item: {
                id: id
            },
            collect: (monitor)=>({
                    isDragging: !!monitor.isDragging()
                }),
            end: (item, monitor)=>{
                if (monitor.didDrop()) {
                    setActif(false);
                }
            }
        }));
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: isActif ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "card pl-2 pr-2 drop-area",
            style: {
                touchAction: isDragging ? "none" : "auto",
                cursor: isDragging ? "grabbing" : "grab",
                opacity: isDragging ? 0 : 1
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: id == 4 ? "relative max-w-sm overflow-hidden shadow-lg z-40" : "relative max-w-sm overflow-hidden shadow-lg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        className: "pt-3 flex w-44 h-44 m-1 cavalierImage",
                        ref: drag,
                        src: imageURL,
                        width: "130",
                        height: "144",
                        alt: "Image principale",
                        draggable: false
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "absolute inset-x-0 -bottom-1  flex flex-col shadow-lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/images/card/vague.png",
                            width: 143,
                            height: 100,
                            alt: "Image rouge",
                            className: "z-10 w-full mr-2 ml-0.5 cavalierImage",
                            draggable: "false"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "absolute inset-x-0 bottom-0 z-20 p-4 text-black",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "relative",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "top-6 font-bold text-white absolute left-3",
                                    style: Number(score) <= 99 ? {
                                        fontSize: "10px"
                                    } : {
                                        fontSize: "8px"
                                    },
                                    children: score
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "relative top-3.5 left-10 uppercase cardTexte",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                        className: "font-bold mt-0 mb-0",
                                        style: {
                                            fontSize: "10px"
                                        },
                                        children: lastName
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "flex top-1 hover:underline",
                                        style: {
                                            fontSize: "8px"
                                        },
                                        children: firstName
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
    });
};
/* harmony default export */ const riderCardTuto = (RiderCardTuto);

// EXTERNAL MODULE: ./app/api/AppStateContext.tsx + 1 modules
var AppStateContext = __webpack_require__(8618);
;// CONCATENATED MODULE: ./app/tutorial/components/confirmBoutton.tsx


const ConfirmBoutton = ()=>{
    const { appState, classementState } = (0,AppStateContext/* useAppState */.m)();
    const storeData = ()=>{
        const jsonData = JSON.stringify(classementState);
        const binId = "6512b9f512a5d376598366df";
        // Définis l'URL de l'API JSONBin
        const jsonBinUrl = `https://api.jsonbin.io/v3/b/${binId}`;
        // Remplace 'YOUR_API_KEY' par ta clé d'API JSONBin
        const apiKey = "$2b$10$./sSv/f/M/JgpEY0veOnxOzSP/axiTaaE5jikEaw0TqAk6w6Wc.SW";
        // Configuration de la requête GET pour récupérer les données actuelles
        const getOptions = {
            method: "GET",
            headers: {
                "X-Master-Key": apiKey
            }
        };
        fetch(jsonBinUrl, getOptions).then((response)=>response.json()).then((currentData)=>{
            // Get le prochain numéro
            let nextIteration = 1;
            while(currentData.record[`newData${nextIteration}`]){
                nextIteration++;
            }
            const newKeyName = `newData${nextIteration}`;
            // Ajoute les nouvelles données dans une clé
            currentData.record[newKeyName] = classementState;
            // Met à jour les donnés avec les nouvelles valeurs
            const updatedData = currentData.record;
            // Configuration de la requête PUT pour mettre à jour le bin
            const putOptions = {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    "X-Master-Key": apiKey
                },
                body: JSON.stringify(updatedData)
            };
            // Envoie la requête PUT pour mettre à jour le bin
            return fetch(jsonBinUrl, putOptions);
        }).then((response)=>{
            if (response.status === 200) {
                console.log("Donn\xe9es mises \xe0 jour avec succ\xe8s.");
            } else {
                console.error("Erreur lors de la mise \xe0 jour des donn\xe9es.");
            }
        }).catch((error)=>{
            console.error("Erreur lors de la r\xe9cup\xe9ration des donn\xe9es actuelles :", error);
        });
    };
    if (appState[4].isActif === true) {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "relative confirmSession pt-10 flex items-center justify-center",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                className: "relative z-10 px-4 py-2 text-white bg-red-500 font-bold",
                onClickCapture: storeData,
                children: [
                    "CONFIRM",
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute bottom-1.5 left-2 bg-white transform rotate-40"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute bottom-4 -left-0.5 bg-white transform rotate-90"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute top-1.5 right-2 bg-white transform -rotate-40"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "absolute top-4 -right-0.5 bg-white transform -rotate-90"
                    })
                ]
            })
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
    }
};
/* harmony default export */ const confirmBoutton = (ConfirmBoutton);

;// CONCATENATED MODULE: ./app/tutorial/components/confirmText.tsx


const ConfirmText = ()=>{
    const { appState } = (0,AppStateContext/* useAppState */.m)();
    if (appState[4].isActif === true) {
        return /*#__PURE__*/ jsx_runtime_.jsx("h4", {
            className: "flex items-center justify-center font-bold uppercase pt-6 pb-1",
            children: "Your classification is ready! Validate it and try to win your CWD gift."
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "pt-3"
        });
    }
};
/* harmony default export */ const confirmText = (ConfirmText);

// EXTERNAL MODULE: ./app/components/emptyRiderCard.tsx
var emptyRiderCard = __webpack_require__(6506);
;// CONCATENATED MODULE: ./app/components/riderCardFillableTuto.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 





const RiderCardFillableTuto = ({ id, isActif, showNextRider, index })=>{
    const [board, setBoard] = (0,react_.useState)([]);
    const [isActifState, setActif] = (0,react_.useState)(true);
    const { appState } = (0,AppStateContext/* useAppState */.m)();
    // Quand on glisse une image et on la met vers le card rouge cette fonction s'éxecute
    const addImageToBoard = (id)=>{
        // Cherche le card qui a l'id passé en parametre
        const riderCardData = ridersData/* default */.Z.find((rider)=>rider.id === id);
        // Si le card existe est n'est pas null
        if (riderCardData) {
            // Ajouter les informations du card dans le useState board
            setBoard(riderCardData);
        }
        // Déclarer que le card est Actif
        setActif(false);
    };
    // Quand je clique sur l'image du card cette fonction s'execute (pour supprimer le card de sa place)
    const removeImageFromBoard = (id, cardId)=>{
        const allowedIds = [
            1,
            2,
            3
        ];
        if (allowedIds.includes(id)) {
            if (appState[id].isActif === true && appState[id - 1].isActif === false) {
                // Cherche le card grâce a son Id puis enleve l'image et met a la place un card rouge pour acceuillir une nouvelle image
                showNextRider(id, "remove", cardId);
                setActif(true);
            }
        } else {
            if (id === 0) {
                if (appState[id].isActif == true) {
                    // Cherche le card grâce a son Id puis enleve l'image et met a la place un card rouge pour acceuillir une nouvelle image
                    showNextRider(id, "remove", cardId);
                    setActif(true);
                }
            } else {
                // Cherche le card grâce a son Id puis enleve l'image et met a la place un card rouge pour acceuillir une nouvelle image
                showNextRider(id, "remove", cardId);
                setActif(true);
            }
        }
    };
    return isActifState ? // Si le card n'est pas actif (c'est à dire pas d'image de card) cela met le card rouge
    /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "pt-20 m-1 pl-2 pr-2",
        children: /*#__PURE__*/ jsx_runtime_.jsx(emptyRiderCard/* default */.Z, {
            id: index,
            isActif: isActif,
            showNextRider: showNextRider,
            addImageToBoard: addImageToBoard
        })
    }) : // Sinon met le card avec l'image
    /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "pt-16",
        onClickCapture: ()=>removeImageFromBoard(index, board.id),
        children: /*#__PURE__*/ jsx_runtime_.jsx(riderCardTuto, {
            id: board.id,
            lastName: board.lastName + " e",
            firstName: board.firstName,
            imageURL: board.imageURL,
            score: board.score
        })
    }, index);
};
/* harmony default export */ const riderCardFillableTuto = (RiderCardFillableTuto);

// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(7114);
;// CONCATENATED MODULE: ./app/tutorial/page.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 










const Tutorial = ()=>{
    const [ridersDataa, setRidersData] = (0,react_.useState)(ridersData/* default */.Z);
    const [data, setData] = (0,react_.useState)(ridersData/* default */.Z);
    const [tutorialTextTitle, setTutorialTextTitle] = (0,react_.useState)("DRAG THIS PILOT CARD TO THE TOP SPOT!");
    const [tutorialTextSubtitle, setTutorialTextSubtitle] = (0,react_.useState)("");
    const [steps, setSteps] = (0,react_.useState)(0);
    const [isAnimating, setIsAnimating] = (0,react_.useState)(false);
    const { push } = (0,navigation.useRouter)();
    const { appState, classementState, updateAddItemById, updateAddClassement, updateRemoveClassement } = (0,AppStateContext/* useAppState */.m)();
    const handleStateChange = (title, subtitle)=>{
        setIsAnimating(true);
        setTimeout(()=>{
            setTutorialTextTitle(title);
            setTutorialTextSubtitle(subtitle);
            setIsAnimating(false);
        }, 1000);
    };
    // useEffect pour observer les changements d'état
    //     useEffect(() => {
    //   console.log("Nouvel état : ", classementState);
    //     }, [classementState]);
    const showNextRider = (id, type, cardid)=>{
        const updatedRidersData = [
            ...ridersDataa
        ];
        if (type === "add") {
            setSteps(1);
            handleStateChange("CHANGE YOUR MIND?", "REPLACE THE PILOT CARD IN ITS INITIAL POSITION BY CLICKING ON IT");
            updateAddClassement(updatedRidersData[cardid].firstName + " " + updatedRidersData[cardid].lastName);
            if (updatedRidersData[id].id != updatedRidersData[4].id) {
                // Relalive au cards avec les nombres
                updatedRidersData[id].isActif = false;
                updatedRidersData[id + 1].isActif = true;
                // console.log("id: " + id +  " cardId: " + cardid);
                updateAddItemById(id); // Met le isActif de cet item avec cet id en False
                // Mise à jour de la Data pour faire un mapping
                setRidersData(updatedRidersData);
            } else {
                updatedRidersData[id].isActif = true;
                updateAddItemById(id);
                // Mise à jour de la Data pour faire un mapping
                setRidersData(updatedRidersData);
            }
        } else {
            handleStateChange("GREAT, GOOD JOB", "YOU'LL BE STARTING IN A MOMENT...");
            updateRemoveClassement();
            if (cardid != updatedRidersData.length + 1) {
                if (updatedRidersData[id + 1]?.isActif === true) {
                    // Mettre la data pour afficher les cards en haut à jour
                    const oldData = [
                        ...data
                    ];
                    const newData = oldData.find((rider)=>rider.id === cardid);
                    const FiltredData = [
                        ...data,
                        newData
                    ];
                    setData(FiltredData);
                    updateAddItemById(id - 1); // Met le isActif de cet item avec cet id en True
                } else {
                    // annuler l'action
                    updateAddItemById(id - 1); // Met le isActif de cet item avec cet id en True
                }
                // A supprimer après les testes
                // console.log("calavierId : ", cardid);
                // console.log("cardId : ", id);
                // Vérifier si le card que je veux supprimer de la liste est le dernier sinon ne rien faire
                if (id != 4) {
                    if (updatedRidersData[id + 1].isActif === true) {
                        // Quand un choix est fait et posé dans le card le card suivant est mis en rouge pour poser un nouveau card
                        switch(id){
                            case 0:
                                updatedRidersData[0].isActif = true;
                                updatedRidersData[1].isActif = false;
                                break;
                            case 1:
                                updatedRidersData[1].isActif = true;
                                updatedRidersData[2].isActif = false;
                                break;
                            case 2:
                                updatedRidersData[2].isActif = true;
                                updatedRidersData[3].isActif = false;
                                break;
                            case 3:
                                updatedRidersData[3].isActif = true;
                                updatedRidersData[4].isActif = false;
                                break;
                            default:
                                updatedRidersData[4].isActif = true;
                                break;
                        }
                    }
                } else {
                    updatedRidersData[4].isActif = true;
                    // Mettre la data pour afficher les cards en haut à jour
                    const oldData = [
                        ...data
                    ];
                    const newData = oldData.find((rider)=>rider.id === cardid);
                    const FiltredData = [
                        ...data,
                        newData
                    ];
                    setData(FiltredData);
                }
                // Mise à jour de la Data pour faire un mapping
                setRidersData(updatedRidersData);
                setTimeout(()=>{
                    push("/start");
                }, 3000);
            } else {
                // Remettre la data pour afficher les cards en haut à jour
                const oldData = [
                    ...data
                ];
                const newData = oldData.find((rider)=>rider.id === cardid);
                const FiltredData = [
                    ...data,
                    newData
                ];
                setData(FiltredData);
                updatedRidersData[id].isActif = true;
                setRidersData(updatedRidersData);
                updateAddItemById(id - 1);
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tutorialMainDiv z-30"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: "/images/card/click.png",
                alt: "Click Image",
                className: steps === 0 ? `absolute flex image-animation z-50` : `absolute flex image-animation-static z-50`,
                width: 100,
                height: 100
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "m-0",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pt-9",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "flex items-center justify-center font-bold",
                                children: "CWD CHAMPIONS CUP"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-black text-center text-sm",
                                children: "We care. They ride."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "pt-5 tutorialTitle",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "flex items-center justify-center font-bold uppercase",
                                children: "PREDICT THE RANKING OF CWD RIDERS AT THE FEI 5* WORLD CUP IN TORONTO."
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(confirmText, {})
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "tutorialText",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: `text-center font-sans text-white relative z-50 text-3xl top-32 left-24 whitespace-pre-line ${isAnimating ? "fadeOut" : "fadeIn"} transition-opacity`,
                                children: tutorialTextTitle
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: `text-center font-sans text-white relative z-50 top-32 whitespace-pre-line ${isAnimating ? "fadeOut" : "fadeIn"} transition-opacity`,
                                children: tutorialTextSubtitle
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid grid-cols-5",
                        children: data.map((rider, index)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx(riderCardTuto, {
                                id: rider.id,
                                lastName: rider.lastName,
                                firstName: rider.firstName,
                                imageURL: rider.imageURL,
                                score: rider.score
                            }, index);
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid grid-cols-5",
                        children: ridersDataa.map((item, index)=>{
                            return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: index === 0 ? "z-40" : "",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(riderCardFillableTuto, {
                                    id: item.id,
                                    index: index,
                                    isActif: item.isActif,
                                    showNextRider: showNextRider
                                })
                            }, index);
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(confirmBoutton, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Tutorial);


/***/ }),

/***/ 6575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Stage\Desktop\WORKSPACE\Jeux\app\tutorial\page.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 7114:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(696)


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [587,333,811,269,712], () => (__webpack_exec__(3770)));
module.exports = __webpack_exports__;

})();