exports.id = 712;
exports.ids = [712];
exports.modules = {

/***/ 7264:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23))

/***/ }),

/***/ 6506:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8073);
/* __next_internal_client_entry_do_not_use__ default auto */ 

const EmptyRiderCard = ({ id, isActif, addImageToBoard, showNextRider })=>{
    const [{ isOver }, drop] = (0,react_dnd__WEBPACK_IMPORTED_MODULE_1__/* .useDrop */ .L)(()=>({
            accept: "image",
            drop: (item)=>{
                addImageToBoard(item.id);
                showNextRider(id, "add", item.id);
            },
            collect: (monitor)=>({
                    isOver: !!monitor.isOver()
                })
        }));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isActif ? // Si le card est actif 
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            ref: drop,
            className: `w-42 h-40 text-white flex items-center justify-center text-2xl font-bold drop-area bg-red-500`,
            children: id + 1
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            ref: null,
            className: `w-42 h-40 text-white flex items-center justify-center text-2xl font-bold drop-area bg-gray-500`,
            children: id + 1
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmptyRiderCard);


/***/ }),

/***/ 255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const img = "/images/riders/";
const getImageURL = (name)=>{
    return img + name + ".png";
};
const RidersData = [
    {
        id: 0,
        lastName: "Conor",
        firstName: "Swail",
        imageURL: getImageURL("conor-swail"),
        score: "08",
        isActif: true
    },
    {
        id: 1,
        lastName: "Hunter",
        firstName: "Halloway",
        imageURL: getImageURL("hunter-halloway"),
        score: "160",
        isActif: false
    },
    {
        id: 2,
        lastName: "Kent",
        firstName: "Farrington",
        imageURL: getImageURL("kent-farrington"),
        score: "09",
        isActif: false
    },
    {
        id: 3,
        lastName: "Mclain",
        firstName: "Ward",
        imageURL: getImageURL("mclain-ward"),
        score: "03",
        isActif: false
    },
    {
        id: 4,
        lastName: "Natalie",
        firstName: "Dean",
        imageURL: getImageURL("natalie-dean"),
        score: "80",
        isActif: false
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RidersData);


/***/ })

};
;