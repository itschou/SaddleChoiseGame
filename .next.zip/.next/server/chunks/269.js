exports.id = 269;
exports.ids = [269];
exports.modules = {

/***/ 5630:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6514))

/***/ }),

/***/ 8618:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  W: () => (/* binding */ AppStateProvider),
  m: () => (/* binding */ useAppState)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./app/data/cardsStateData.ts
const cardsStateData = [
    {
        id: 0,
        isActif: false
    },
    {
        id: 1,
        isActif: false
    },
    {
        id: 2,
        isActif: false
    },
    {
        id: 3,
        isActif: false
    },
    {
        id: 4,
        isActif: false
    }
];
/* harmony default export */ const data_cardsStateData = (cardsStateData);

;// CONCATENATED MODULE: ./app/api/AppStateContext.tsx



const initialAppState = [
    ...data_cardsStateData
];
const AppStateContext = /*#__PURE__*/ (0,react_.createContext)(undefined);
function AppStateProvider({ children }) {
    const [appState, setAppState] = (0,react_.useState)(()=>initialAppState);
    const [classementState, setClassementState] = (0,react_.useState)([]);
    // useEffect(() => {
    //   console.log("Nouvel état : ", classementState);
    // }, [classementState]);
    // Fonction pour mettre à jour l'état d'un élément par son id
    const updateAddItemById = (id)=>{
        const updatedState = appState.map((item)=>({
                ...item,
                isActif: item.id === id
            }));
        setAppState(updatedState);
    };
    // Fonction pour mettre à jour l'état du classement (Ajouter un cavalier a la liste)
    const updateAddClassement = (nomCavalier)=>{
        // Prend les anciennes valeurs et rajoute la valeur actuelle
        setClassementState((prevClassementState)=>[
                ...prevClassementState,
                nomCavalier
            ]);
    };
    // Fonction pour mettre à jour l'état du classement (Supprimer un cavalier a la liste)
    const updateRemoveClassement = ()=>{
        setClassementState((prevClassementState)=>prevClassementState.slice(0, -1) // Supprime le dernier élément
        );
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(AppStateContext.Provider, {
        value: {
            appState,
            classementState,
            setAppState,
            updateAddItemById,
            updateAddClassement,
            updateRemoveClassement
        },
        children: children
    });
}
function useAppState() {
    const context = (0,react_.useContext)(AppStateContext);
    if (context === undefined) {
        throw new Error("useAppState doit \xeatre utilis\xe9 dans un composant englob\xe9 par AppStateProvider");
    }
    return context;
}


/***/ }),

/***/ 6514:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout),
/* harmony export */   metadata: () => (/* binding */ metadata)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2224);
/* harmony import */ var next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_dnd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(316);
/* harmony import */ var react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7882);
/* harmony import */ var _public_css_main_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(211);
/* harmony import */ var _public_css_main_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_public_css_main_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_css_tutorial_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2537);
/* harmony import */ var _public_css_tutorial_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_public_css_tutorial_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_css_start_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2427);
/* harmony import */ var _public_css_start_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_public_css_start_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_AppStateContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8618);
/* __next_internal_client_entry_do_not_use__ metadata,default auto */ 







const metadata = {
    title: "Create Next App",
    description: "Generated by create next app"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_dnd__WEBPACK_IMPORTED_MODULE_5__/* .DndProvider */ .W, {
        backend: react_dnd_html5_backend__WEBPACK_IMPORTED_MODULE_6__/* .HTML5Backend */ .PD,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("html", {
            lang: "en",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("head", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                    className: (next_font_google_target_css_path_app_layout_tsx_import_Inter_arguments_subsets_latin_variableName_inter___WEBPACK_IMPORTED_MODULE_7___default().className),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_api_AppStateContext__WEBPACK_IMPORTED_MODULE_4__/* .AppStateProvider */ .W, {
                        children: children
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 1921:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $$typeof: () => (/* binding */ $$typeof),
/* harmony export */   __esModule: () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   metadata: () => (/* binding */ e0)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1363);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`C:\Users\Stage\Desktop\WORKSPACE\Jeux\app\layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["metadata"];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (__default__);

/***/ }),

/***/ 7481:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
/* harmony import */ var next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__);
  

  /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props) => {
    const imageData = {"type":"image/x-icon","sizes":"16x16"}
    const imageUrl = (0,next_dist_lib_metadata_get_metadata_route__WEBPACK_IMPORTED_MODULE_0__.fillMetadataSegment)(".", props.params, "favicon.ico")

    return [{
      ...imageData,
      url: imageUrl + "",
    }]
  });

/***/ }),

/***/ 211:
/***/ (() => {



/***/ }),

/***/ 2427:
/***/ (() => {



/***/ }),

/***/ 2537:
/***/ (() => {



/***/ })

};
;